// Minimal JS placeholder; replace with full app JS after route works.
console.log('VoxPro minimal JS loaded');